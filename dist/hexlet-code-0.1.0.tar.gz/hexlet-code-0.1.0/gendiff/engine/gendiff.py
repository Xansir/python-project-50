import json
from .parser import parsing


def generate_diff(file1, file2):
    data = parsing(file1)
    data2 = parsing(file2)

    sorted_data = dict(sorted(data.items()))
    sorted_data2 = dict(sorted(data2.items()))
    keys_d1 = set(sorted_data.keys())
    keys_d2 = set(sorted_data2.keys())
    union_keys = keys_d1.intersection(keys_d2)
    only_d1 = keys_d1.difference(keys_d2)
    only_d2 = keys_d2.difference(keys_d1)

    result = ''
    for key, value in sorted_data.items():
        if value == sorted_data2.get(key):
            result = result + f'   {key}: {sorted_data2[key]}\n'
        if key in only_d1:
            result = result + f' - {key}: {str(sorted_data[key])}\n'
        if key in union_keys:
            if value != sorted_data2.get(key):
                result = result + f' - {key}: {str(sorted_data[key])}\n'
                result = result + f' + {key}: {str(sorted_data2[key])}\n'
    for key, value in sorted_data2.items():
        if key in only_d2:
            result = result + f' + {key}: {str(sorted_data2[key])}\n'
    result = '{\n' + result + '}'
    return result
