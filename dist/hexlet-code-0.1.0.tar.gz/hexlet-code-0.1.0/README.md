### Hexlet tests and linter status:
[![Actions Status](https://github.com/Xansir/python-project-50/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Xansir/python-project-50/actions)

### Build, lint and test:
[![build-lint-test](https://github.com/Xansir/python-project-50/actions/workflows/ci.yml/badge.svg)](https://github.com/Xansir/python-project-50/actions/workflows/ci.yml)

### Code Climate Maintainability & Test Coverage
[![Maintainability](https://api.codeclimate.com/v1/badges/eb044d7d27aab9fce340/maintainability)](https://codeclimate.com/github/Xansir/python-project-50/maintainability)
[![Test Coverage](https://api.codeclimate.com/v1/badges/eb044d7d27aab9fce340/test_coverage)](https://codeclimate.com/github/Xansir/python-project-50/test_coverage)