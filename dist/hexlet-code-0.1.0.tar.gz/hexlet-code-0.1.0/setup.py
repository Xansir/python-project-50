# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['gendiff', 'gendiff.format', 'gendiff.scripts']

package_data = \
{'': ['*']}

install_requires = \
['PyYAML>=6.0.1,<7.0.0', 'pytest-cov>=4.1.0,<5.0.0', 'pytest>=7.4.4,<8.0.0']

entry_points = \
{'console_scripts': ['gendiff = gendiff.scripts.gendiff:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': 'Cli-utilite for find difference between two json/yaml files',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/Xansir/python-project-50/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Xansir/python-project-50/actions)\n\n### Build, lint and test:\n[![build-lint-test](https://github.com/Xansir/python-project-50/actions/workflows/pyci.yml/badge.svg)](https://github.com/Xansir/python-project-50/actions/workflows/pyci.yml)\n\n### Code Climate Maintainability & Test Coverage\n[![Maintainability](https://api.codeclimate.com/v1/badges/eb044d7d27aab9fce340/maintainability)](https://codeclimate.com/github/Xansir/python-project-50/maintainability)\n[![Test Coverage](https://api.codeclimate.com/v1/badges/eb044d7d27aab9fce340/test_coverage)](https://codeclimate.com/github/Xansir/python-project-50/test_coverage)',
    'author': 'Rodion Rizvanov',
    'author_email': 'xirizvanov@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': 'https://github.com/Xansir/python-project-50.git',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
