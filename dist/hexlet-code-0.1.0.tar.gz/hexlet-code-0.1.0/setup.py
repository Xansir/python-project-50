# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['gendiff', 'gendiff.engine', 'gendiff.scripts']

package_data = \
{'': ['*']}

install_requires = \
['PyYAML>=6.0.1,<7.0.0']

entry_points = \
{'console_scripts': ['gendiff = gendiff.scripts.gendiff:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': 'First project on Hexlet, set of 5 simple mini-games',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/Xansir/python-project-50/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Xansir/python-project-50/actions)',
    'author': 'Rodion Rizvanov',
    'author_email': 'xirizvanov@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': 'https://github.com/Xansir/python-project-50.git',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
